# View more python tutorials on my Youtube and Youku channel!!!

# Youtube video tutorial: https://www.youtube.com/channel/UCdyjiB5H8Pu7aDTNVXTTpcg
# Youku video tutorial: http://i.youku.com/pythontutorial

# 1 - why

"""
1. matplotlib is a powerful python data visualization tool;
2. similar with MATLAB. If know matlab, easy to move over to python;
3. easy to plot 2D, 3D data;
4. you can even make animation.
"""